package AtividadeD.atividadeD.atividadeD;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.awt.*;

public class AtividadeD_Controller {
    @FXML
    private Label titulo;

    @FXML
    private TextField palavra;

    @FXML
    private Button contar;

    @FXML
    private Label texto;




   }